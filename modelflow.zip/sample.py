import os
from pprint import pprint
import mlflow

path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
mlflow_model = mlflow.pyfunc.load_model(path_to_export)

# MLflow provides a model.predict method to get scoring for a given input data.
#
# MLflow does not provide a model.predict_proba method to get probabilities in case of classification.
# If you want to get probabilities, use the regular Python export instead, or load the model with
# the load_model method from dataikuscoring.
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "code": 10003
        ,"region": "Oceania"
        ,"country": "Australia"
        ,"area": "Northern Territory: Offshore"
        ,"latitude": -13.227500000000001
        ,"longitude": 129.74277777777777
        ,"site_name": "Eastern Petrel Sub-basin: Cretaceous reservoirs"
        ,"basin": "Bonaparte"
        ,"formation": "Sandpiper Sandstone Formation"
        ,"unit_designation": "Saline Aquifer"
        ,"type": "Saline"
        ,"storage_unit_type": "Open, no identified structural/ stratigraphic confinement"
        ,"discovery_status": "Discovered awaiting detailed evaluation"
        ,"age": "Lower Cretaceous"
        ,"publication": "Australian Government: Geoscience Australia. 2014. \u201cRegional assessment of the CO2 storage potential of the Mesozoic succession in the Petrel Sub-basin, Northern Territory, Australia.\u201d"
        ,"project_history": "Geoscience Australia commissioned by the Australian Government to undertake a series of regional, geological studies to assess the CO2 storage potential of the Australian sedimentary basins, as part of the National Low Emissions Coal Initiative. Detailed geological study developed structural and geological models on the centre and eastern areas of the Petrel sub-basin."
        ,"development_plan": "No development plan for regional resource estimation (dynamic simulation for Petrel field area: see additional site in database)."
        ,"containment_summary": "Trapping model relies  on residual and dissolution trapping with long migration-assisted storage with long pathways (50-70km). Overlying seal is Bathhurst Island Sequence sediments (Echuca Shoals, Darwin Formation and Wangarlu Formation). Mudstones calculated to have sealing capacity to hold back a CO2 column height of 137-365m. Geomechanical risk (fault re-activation/slippage) is an issue and requires further investigation (limited data available; Stalker et al 2020)."
        ,"assessment_notes": "Reservoir characteristics taken from Petrel-1. Porosity is log porosity. Depth calculated from mid-point on the depth map (approx. 1550m) plus half the approximate thickness at the same mid-point location (approx. 660m), from Figure 6.11. Partial discovery (85%) of the reservoir, calculated using the well density (34 wells over AOI of 80 x 100km) in the aquifer (resource estimate adjusted). Risk of double counting with the Bonaparte Basin from the Australian Government (2009) National Infrastructure Plan."
        ,"year_of_publication": "2014"
        ,"date_of_assessment": "Cycle 1"
        ,"site_area_km2": 8000.0
        ,"depth": "2200"
        ,"thickness_m": "168.5"
        ,"ntg": 0.97
        ,"porosity": "19.7"
        ,"permeability_md": "159"
        ,"brine_salinity": "0"
        ,"co2_density": 0.0
        ,"well_count": 34
        ,"well_density": 0.00425
        ,"single_well_discovery_area": 200
        ,"pressure_psig": 0.0
        ,"source_of_storage_efficiency_factor": "Bradshaw et al 2009. Data from static and dynamic models used to constrain inputs (variability evaluated using Monte Carlo model to address uncertainties). Probabilistic effective storage estimate."
        ,"storage_efficiency": "0"
        ,"pore_compressibility": "0"
        ,"frac_pressure": "0"
        ,"pre_injection_pressure": "0"
        ,"source_of_analogue": "Derived from static and dynamic models. Inputs evaluated using Monte Carlo model."
        ,"assessment": "Assessed"
        ,"stored_low": 0.0
        ,"stored_mid": 0.0
        ,"stored_high": 0
        ,"on_injection_low": 0
        ,"on_injection_mid": 0.0
        ,"on_injection_high": 0
        ,"approved_for_development_low": 0
        ,"approved_for_development_mid": 0
        ,"approved_for_development_high": 0
        ,"justified_for_development_low": 0.0
        ,"justified_for_development_mid": 0.0
        ,"justified_for_development_high": 0
        ,"development_pending_low": 0
        ,"development_pending_mid": 0.0
        ,"development_pending_high": 0
        ,"development_on_hold_low": 0
        ,"development_on_hold_mid": 0.0
        ,"development_on_hold_high": 0
        ,"development_not_viable_low": 0.0
        ,"development_not_viable_mid": 7786.0
        ,"development_not_viable_high": 0.0
        ,"development_unclarified_low": 0.0
        ,"development_unclarified_mid": 0.0
        ,"development_unclarified_high": 0.0
        ,"inaccessible_subcommercial_low": 0.0
        ,"inaccessible_subcommercial_mid": 0.0
        ,"inaccessible_subcommercial_high": 0.0
        ,"prospect_low": 0.0
        ,"prospect_mid": 0.0
        ,"prospect_high": 0.0
        ,"lead_low": 0.0
        ,"lead_mid": 0.0
        ,"lead_high": 0.0
        ,"sequence_play_low": 0.0
        ,"sequence_play_mid": 1374.0
        ,"sequence_play_high": 0.0
        ,"basin_play_low": 0.0
        ,"basin_play_mid": 0.0
        ,"basin_play_high": 0.0
        ,"undiscovered_inaccessible_low": 0.0
        ,"undiscovered_inaccessible_mid": 0.0
        ,"undiscovered_inaccessible_high": 0.0
        ,"total_low": 0.0
        ,"total_mid": 9160.0
        ,"total_high": 0.0
        ,"sum_low": 0.0
        ,"sum_mid": 9160.0
        ,"sum_high": 0.0
        ,"flowtest": False
        ,"rocktype": "Clastic"
        ,"p50_pore_volume_mmcum": 0
        ,"prop_considered_discovered": 0.8500000000000001
    }
    ,{
        "code": 10004
        ,"region": "Oceania"
        ,"country": "Australia"
        ,"area": "Northern Territory: Offshore"
        ,"latitude": -13.2
        ,"longitude": 129.74277777777777
        ,"site_name": "Eastern Petrel Sub-basin: Jurassic reservoirs"
        ,"basin": "Bonaparte"
        ,"formation": "Plover, Elang and lower Frigate Shale Formations"
        ,"unit_designation": "Saline Aquifer"
        ,"type": "Saline"
        ,"storage_unit_type": "Open, no identified structural/ stratigraphic confinement"
        ,"discovery_status": "Discovered awaiting detailed evaluation"
        ,"age": "Lower to Mid Jurassic"
        ,"publication": "Australian Government: Geoscience Australia. 2014. \u201cRegional assessment of the CO2 storage potential of the Mesozoic succession in the Petrel Sub-basin, Northern Territory, Australia.\u201d"
        ,"project_history": "Geoscience Australia commissioned by the Australian Government to undertake a series of regional, geological studies to assess the CO2 storage potential of the Australian sedimentary basins, as part of the National Low Emissions Coal Initiative. Detailed geological study developed structural and geological models on the centre and eastern areas of the Petrel sub-basin."
        ,"development_plan": "No development plan for regional resource estimation (dynamic simulation for Petrel field area: see additional site in database)."
        ,"containment_summary": "Trapping model relies  on residual and dissolution trapping with long migration-assisted storage with long pathways (50-70km). Overlying seal is Upper Frigate Shale. Upper parts of caprock have reduced seal capacity (transitions into Sandpiper Sandstone) but lower shale is mud-rick and fissile (from cuttings data). Geomechanical risk (fault re-activation/slippage) is an issue and requires further investigation (limited data available; Stalker et al 2020)."
        ,"assessment_notes": "Reservoir characteristics taken from Petrel-1. Porosity is log porosity. Depth taken from the mid-point in Figure 4.7b. Partial discovery (13%) of the reservoir, calculated using the well density in the aquifer. Risk of double counting with the Bonaparte Basin from the Australian Government (2009) National Infrastructure Plan."
        ,"year_of_publication": "2014"
        ,"date_of_assessment": "Cycle 1"
        ,"site_area_km2": 8000.0
        ,"depth": "2430"
        ,"thickness_m": "370.6"
        ,"ntg": 0.9
        ,"porosity": "16.9"
        ,"permeability_md": "65"
        ,"brine_salinity": "0"
        ,"co2_density": 0.0
        ,"well_count": 34
        ,"well_density": 0.00425
        ,"single_well_discovery_area": 200
        ,"pressure_psig": 0.0
        ,"source_of_storage_efficiency_factor": "Bradshaw et al 2009. Data from static and dynamic models used to constrain inputs (variability evaluated using Monte Carlo model to address uncertainties). Probabilistic effective storage estimate."
        ,"storage_efficiency": "0"
        ,"pore_compressibility": "0"
        ,"frac_pressure": "0"
        ,"pre_injection_pressure": "0"
        ,"source_of_analogue": "Derived from static and dynamic models. Inputs evaluated using Monte Carlo model."
        ,"assessment": "Assessed"
        ,"stored_low": 0.0
        ,"stored_mid": 0.0
        ,"stored_high": 0
        ,"on_injection_low": 0
        ,"on_injection_mid": 0.0
        ,"on_injection_high": 0
        ,"approved_for_development_low": 0
        ,"approved_for_development_mid": 0
        ,"approved_for_development_high": 0
        ,"justified_for_development_low": 0.0
        ,"justified_for_development_mid": 0.0
        ,"justified_for_development_high": 0
        ,"development_pending_low": 0
        ,"development_pending_mid": 0.0
        ,"development_pending_high": 0
        ,"development_on_hold_low": 0
        ,"development_on_hold_mid": 0.0
        ,"development_on_hold_high": 0
        ,"development_not_viable_low": 0.0
        ,"development_not_viable_mid": 5151.0
        ,"development_not_viable_high": 0.0
        ,"development_unclarified_low": 0.0
        ,"development_unclarified_mid": 0.0
        ,"development_unclarified_high": 0.0
        ,"inaccessible_subcommercial_low": 0.0
        ,"inaccessible_subcommercial_mid": 0.0
        ,"inaccessible_subcommercial_high": 0.0
        ,"prospect_low": 0.0
        ,"prospect_mid": 0.0
        ,"prospect_high": 0.0
        ,"lead_low": 0.0
        ,"lead_mid": 0.0
        ,"lead_high": 0.0
        ,"sequence_play_low": 0.0
        ,"sequence_play_mid": 909.0
        ,"sequence_play_high": 0.0
        ,"basin_play_low": 0.0
        ,"basin_play_mid": 0.0
        ,"basin_play_high": 0.0
        ,"undiscovered_inaccessible_low": 0.0
        ,"undiscovered_inaccessible_mid": 0.0
        ,"undiscovered_inaccessible_high": 0.0
        ,"total_low": 0.0
        ,"total_mid": 6060.0
        ,"total_high": 0.0
        ,"sum_low": 0.0
        ,"sum_mid": 6060.0
        ,"sum_high": 0.0
        ,"flowtest": False
        ,"rocktype": "Clastic"
        ,"p50_pore_volume_mmcum": 0
        ,"prop_considered_discovered": 0.8500000000000001
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = mlflow_model.predict(data_to_score)
print(" \nOutput of model.predict():\n")
pprint(predict_result)

