import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "DATEPRD": "2015-03-30"
        ,"WELL_BORE_CODE": "NO 15/9-F-11 H"
        ,"NPD_WELL_BORE_CODE": 7078
        ,"NPD_WELL_BORE_NAME": "15/9-F-11"
        ,"NPD_FIELD_CODE": 3420717
        ,"NPD_FIELD_NAME": "VOLVE"
        ,"NPD_FACILITY_CODE": 369304
        ,"NPD_FACILITY_NAME": "MÆRSK INSPIRER"
        ,"ON_STREAM_HRS": 24.0
        ,"AVG_DOWNHOLE_PRESSURE": 220.09
        ,"AVG_DOWNHOLE_TEMPERATURE": 105.48
        ,"AVG_DP_TUBING": 168.78
        ,"AVG_ANNULUS_PRESS": 21.5
        ,"AVG_CHOKE_SIZE_P": 21.99
        ,"AVG_CHOKE_UOM": "%"
        ,"AVG_WHP_P": 51.31
        ,"AVG_WHT_P": 74.98
        ,"DP_CHOKE_SIZE": 22.31
        ,"BORE_OIL_VOL": 1927.71
        ,"BORE_GAS_VOL": 278374.04
        ,"BORE_WAT_VOL": 728.06
        ,"BORE_WI_VOL": 0
        ,"FLOW_KIND": "production"
        ,"WELL_TYPE": "OP"
        ,"EVENT_SEGMENT": 15
        ,"IS_PEAK_START": 0
        ,"DCA_Di": 0.0028522794943783
        ,"DCA_b": 0.0100000000000005
        ,"DCA_R2": 0.8945264311265568
        ,"DCA_Type": "hyperbolic"
        ,"SYN_SEG_ASSIGNED_LAYERS_IDS": "4,7,8"
        ,"SYN_SEG_ASSIGNED_LAYERS_COUNT": 3.0
        ,"SYN_SEG_NET_PAY_FT": 42.239999999999995
        ,"SYN_SEG_AVG_POROSITY": 0.17701799242424246
        ,"SYN_SEG_AVG_INITIAL_SW": 0.2434533617424243
        ,"SYN_SEG_AVG_PERM_MD": 627.304950284091
        ,"SYN_SEG_RE_FT": 587.2604166666666
        ,"SYN_SEG_OOIP_PROXY_MMSTB": 2.4637578013380947
        ,"SYN_OIL_VISCOSITY_PROXY_CP": 1.8
        ,"SYN_OIL_FVF_PROXY_RB_STB": 1.362057203154285
        ,"SYN_OIL_DENSITY_API": 35.29007168040987
        ,"SYN_GOR_SCF_STB": 651.3257253458647
        ,"SYN_SEG_EFFECTIVE_KH_PROXY_MD_FT": 1.0
        ,"SYN_SEG_MOBILITY_PROXY": 0.013152356902356903
        ,"SYN_RESERVOIR_PRESSURE_PROXY_PSIA": 396.59766077687993
        ,"SYN_WATER_INJECTION_SUPPORT_FACTOR": 0.6016566351370807
        ,"CUM_OIL_VOL_WELL": 5876.85
        ,"SYN_SKIN_FACTOR": -1.4816874378613676
        ,"SYN_PERFORATION_EFFICIENCY": 0.7075397185632818
        ,"SYN_WELLBORE_RADIUS_FT": 0.328
    }
    ,{
        "DATEPRD": "2015-03-31"
        ,"WELL_BORE_CODE": "NO 15/9-F-11 H"
        ,"NPD_WELL_BORE_CODE": 7078
        ,"NPD_WELL_BORE_NAME": "15/9-F-11"
        ,"NPD_FIELD_CODE": 3420717
        ,"NPD_FIELD_NAME": "VOLVE"
        ,"NPD_FACILITY_CODE": 369304
        ,"NPD_FACILITY_NAME": "MÆRSK INSPIRER"
        ,"ON_STREAM_HRS": 24.0
        ,"AVG_DOWNHOLE_PRESSURE": 219.66
        ,"AVG_DOWNHOLE_TEMPERATURE": 105.49
        ,"AVG_DP_TUBING": 168.57
        ,"AVG_ANNULUS_PRESS": 21.07
        ,"AVG_CHOKE_SIZE_P": 21.95
        ,"AVG_CHOKE_UOM": "%"
        ,"AVG_WHP_P": 51.1
        ,"AVG_WHT_P": 74.7
        ,"DP_CHOKE_SIZE": 22.32
        ,"BORE_OIL_VOL": 1917.89
        ,"BORE_GAS_VOL": 272552.79
        ,"BORE_WAT_VOL": 706.81
        ,"BORE_WI_VOL": 0
        ,"FLOW_KIND": "production"
        ,"WELL_TYPE": "OP"
        ,"EVENT_SEGMENT": 15
        ,"IS_PEAK_START": 0
        ,"DCA_Di": 0.0028522794943783
        ,"DCA_b": 0.0100000000000005
        ,"DCA_R2": 0.8945264311265568
        ,"DCA_Type": "hyperbolic"
        ,"SYN_SEG_ASSIGNED_LAYERS_IDS": "4,7,8"
        ,"SYN_SEG_ASSIGNED_LAYERS_COUNT": 3.0
        ,"SYN_SEG_NET_PAY_FT": 42.239999999999995
        ,"SYN_SEG_AVG_POROSITY": 0.17701799242424246
        ,"SYN_SEG_AVG_INITIAL_SW": 0.2434533617424243
        ,"SYN_SEG_AVG_PERM_MD": 627.304950284091
        ,"SYN_SEG_RE_FT": 587.2604166666666
        ,"SYN_SEG_OOIP_PROXY_MMSTB": 2.4637578013380947
        ,"SYN_OIL_VISCOSITY_PROXY_CP": 1.8
        ,"SYN_OIL_FVF_PROXY_RB_STB": 1.362057203154285
        ,"SYN_OIL_DENSITY_API": 35.29007168040987
        ,"SYN_GOR_SCF_STB": 651.3257253458647
        ,"SYN_SEG_EFFECTIVE_KH_PROXY_MD_FT": 1.0
        ,"SYN_SEG_MOBILITY_PROXY": 0.013152356902356903
        ,"SYN_RESERVOIR_PRESSURE_PROXY_PSIA": 395.6211210536218
        ,"SYN_WATER_INJECTION_SUPPORT_FACTOR": 0.6016566351370807
        ,"CUM_OIL_VOL_WELL": 7794.740000000001
        ,"SYN_SKIN_FACTOR": -1.4816874378613676
        ,"SYN_PERFORATION_EFFICIENCY": 0.7075397185632818
        ,"SYN_WELLBORE_RADIUS_FT": 0.328
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict()\n")
pprint(predict_result)
