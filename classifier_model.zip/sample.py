import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "NPD_WELL_BORE_NAME": "15/9-F-12"
        ,"NPD_FIELD_NAME": "VOLVE"
        ,"primary_date": "2017-09-18"
        ,"Vibration": 0.0731852898335176
        ,"Intake_Pressure": 252.4027282516753
        ,"Discharge_Pressure": 1190.396396823495
        ,"Intake_Temperature": 223.5407799120564
        ,"Motor_Temperature": 208.9142398875954
        ,"Frequency": 42.19287188595703
        ,"AVG_DOWNHOLE_PRESSURE": 0.0
        ,"AVG_DOWNHOLE_TEMPERATURE": 0.0
        ,"AVG_DP_TUBING": 32.19
        ,"AVG_ANNULUS_PRESS": 14.53
        ,"AVG_CHOKE_SIZE_P": 60.04
        ,"AVG_WHP_P": 32.19
        ,"AVG_WHT_P": 90.69
        ,"DP_CHOKE_SIZE": 3.57
        ,"OIL_RATE_numeric": 181.22
        ,"BORE_OIL_VOL_numeric": 181.22
        ,"Color": "green"
        ,"Status": "Pumping"
        ,"NPD_FACILITY_NAME": "MÆRSK INSPIRER"
        ,"AVG_CHOKE_UOM": "%"
        ,"DATE": "2017-09-18"
        ,"DATEPRD": "2013-10-29"
        ,"records_aggregated": 1
        ,"join_method": "aggregated_time_series"
        ,"join_timestamp": "2025-06-15 13:33:08.772"
        ,"year": 2017
        ,"month": 9
        ,"day": 18
        ,"dayofweek": 0
        ,"quarter": 3
        ,"sequence_number": 1
        ,"Discharge_Pressure_predicted": 1173.6320092773435
        ,"Discharge_Pressure_residual": 16.764387546151283
        ,"Frequency_predicted": 45.91878749676623
        ,"Frequency_residual": -3.725915610809196
        ,"Intake_Pressure_predicted": 409.0636666870117
        ,"Intake_Pressure_residual": -156.66093843533642
        ,"Intake_Temperature_predicted": 227.8151893615723
        ,"Intake_Temperature_residual": -4.274409449515872
        ,"Motor_Temperature_predicted": 226.27777313232423
        ,"Motor_Temperature_residual": -17.363533244728842
        ,"Vibration_predicted": 1.1602107365429402
        ,"Vibration_residual": -1.0870254467094225
        ,"Discharge_Pressure_avg": 1151.990607044403
        ,"Discharge_Pressure_std": 157.9238776987151
        ,"Discharge_Pressure_slope": 211.99034689243263
        ,"Frequency_avg": 44.61879189690259
        ,"Frequency_std": 2.7216044003948516
        ,"Frequency_slope": -1.9087601975563544
        ,"Intake_Pressure_avg": 528.6841462226597
        ,"Intake_Pressure_std": 335.80590118802144
        ,"Intake_Pressure_slope": -178.8015912732391
        ,"Intake_Temperature_avg": 232.20084206902425
        ,"Intake_Temperature_std": 10.828184525542003
        ,"Intake_Temperature_slope": -20.800475601077494
        ,"Motor_Temperature_avg": 217.76238777618178
        ,"Motor_Temperature_std": 12.61377444543398
        ,"Motor_Temperature_slope": -3.252740061522303
        ,"Vibration_avg": 0.6877497296050791
        ,"Vibration_std": 0.5522437933716088
        ,"Vibration_slope": -1.0691766272256014
        ,"OIL_RATE_numeric_avg": 203.98333333333335
        ,"OIL_RATE_numeric_std": 65.15871417802332
        ,"OIL_RATE_numeric_slope": 27.960000000000008
        ,"Discharge_Pressure_residual_avg": -10.22181991685988
        ,"Discharge_Pressure_residual_std": 122.78252367226072
        ,"Discharge_Pressure_residual_slope": 161.0170918875499
        ,"Frequency_residual_avg": -1.6635498866412302
        ,"Frequency_residual_std": 2.1522752598287997
        ,"Frequency_residual_slope": -1.8926012481459087
        ,"Intake_Pressure_residual_avg": 79.96287145255886
        ,"Intake_Pressure_residual_std": 307.93327661173475
        ,"Intake_Pressure_residual_slope": -125.08841271488953
        ,"Intake_Temperature_residual_avg": 4.814015693698707
        ,"Intake_Temperature_residual_std": 9.843686670458808
        ,"Intake_Temperature_residual_slope": -19.54436872851889
        ,"Motor_Temperature_residual_avg": -11.478005137636567
        ,"Motor_Temperature_residual_std": 9.480703990919631
        ,"Motor_Temperature_residual_slope": -0.8342839457996547
        ,"Vibration_residual_avg": -0.43930673539483517
        ,"Vibration_residual_std": 0.5744849163453453
        ,"Vibration_residual_slope": -1.0955872294077513
        ,"Discharge_Pressure_trend": "Increase"
        ,"Frequency_trend": "Decrease"
        ,"Intake_Pressure_trend": "Decrease"
        ,"Intake_Temperature_trend": "Decrease"
        ,"Motor_Temperature_trend": "Decrease"
        ,"Vibration_trend": "Decrease"
        ,"OIL_RATE_numeric_trend": "Increase"
        ,"Ampere_trend": "Constant"
    }
    ,{
        "NPD_WELL_BORE_NAME": "15/9-F-12"
        ,"NPD_FIELD_NAME": "VOLVE"
        ,"primary_date": "2017-09-19"
        ,"Vibration": 1.988956901901898
        ,"Intake_Pressure": 671.1304822698015
        ,"Discharge_Pressure": 952.675452785326
        ,"Intake_Temperature": 238.5044791642919
        ,"Motor_Temperature": 220.6264332660505
        ,"Frequency": 52.52480870963878
        ,"AVG_DOWNHOLE_PRESSURE": 0.0
        ,"AVG_DOWNHOLE_TEMPERATURE": 0.0
        ,"AVG_DP_TUBING": 32.61
        ,"AVG_ANNULUS_PRESS": 12.47
        ,"AVG_CHOKE_SIZE_P": 35.23
        ,"AVG_WHP_P": 32.61
        ,"AVG_WHT_P": 84.72
        ,"DP_CHOKE_SIZE": 5.97
        ,"OIL_RATE_numeric": 141.14
        ,"BORE_OIL_VOL_numeric": 141.14
        ,"Color": "green"
        ,"Status": "Pumping"
        ,"NPD_FACILITY_NAME": "MÆRSK INSPIRER"
        ,"AVG_CHOKE_UOM": "%"
        ,"DATE": "2017-09-19"
        ,"DATEPRD": "2013-10-28"
        ,"records_aggregated": 1
        ,"join_method": "aggregated_time_series"
        ,"join_timestamp": "2025-06-15 13:33:08.772"
        ,"year": 2017
        ,"month": 9
        ,"day": 19
        ,"dayofweek": 1
        ,"quarter": 3
        ,"sequence_number": 1
        ,"Discharge_Pressure_predicted": 1212.9479016113282
        ,"Discharge_Pressure_residual": -260.27244882600223
        ,"Frequency_predicted": 46.78010518473567
        ,"Frequency_residual": 5.744703524903116
        ,"Intake_Pressure_predicted": 481.4284028625488
        ,"Intake_Pressure_residual": 189.7020794072527
        ,"Intake_Temperature_predicted": 226.85314407348636
        ,"Intake_Temperature_residual": 11.65133509080556
        ,"Motor_Temperature_predicted": 223.91318740844727
        ,"Motor_Temperature_residual": -3.2867541423967737
        ,"Vibration_predicted": 1.2334611412882803
        ,"Vibration_residual": 0.7554957606136175
        ,"Discharge_Pressure_avg": 1102.161818479634
        ,"Discharge_Pressure_std": 162.9670726791021
        ,"Discharge_Pressure_slope": -237.72094403816902
        ,"Frequency_avg": 46.59529610008664
        ,"Frequency_std": 4.534794644631945
        ,"Frequency_slope": 10.331936823681751
        ,"Intake_Pressure_avg": 564.2957302344453
        ,"Intake_Pressure_std": 283.28397150523705
        ,"Intake_Pressure_slope": 418.72775401812623
        ,"Intake_Temperature_avg": 233.77675134284115
        ,"Intake_Temperature_std": 9.386178503700725
        ,"Intake_Temperature_slope": 14.9636992522355
        ,"Motor_Temperature_avg": 218.47839914864898
        ,"Motor_Temperature_std": 10.39818379889159
        ,"Motor_Temperature_slope": 11.712193378455112
        ,"Vibration_avg": 1.0130515226792838
        ,"Vibration_std": 0.7915810115548169
        ,"Vibration_slope": 1.9157716120683803
        ,"OIL_RATE_numeric_avg": 188.2725
        ,"OIL_RATE_numeric_std": 61.78802331358403
        ,"OIL_RATE_numeric_slope": -40.08000000000001
        ,"Discharge_Pressure_residual_avg": -72.73447714414547
        ,"Discharge_Pressure_residual_std": 160.255092484921
        ,"Discharge_Pressure_residual_slope": -277.0368363721535
        ,"Frequency_residual_avg": 0.18851346624485643
        ,"Frequency_residual_std": 4.099847214445359
        ,"Frequency_residual_slope": 9.470619135712312
        ,"Intake_Pressure_residual_avg": 107.39767344123231
        ,"Intake_Pressure_residual_std": 257.3440148980679
        ,"Intake_Pressure_residual_slope": 346.3630178425891
        ,"Intake_Temperature_residual_avg": 6.52334554297542
        ,"Intake_Temperature_residual_std": 8.734186413854413
        ,"Intake_Temperature_residual_slope": 15.925744540321432
        ,"Motor_Temperature_residual_avg": -9.430192388826619
        ,"Motor_Temperature_residual_std": 8.75766218761494
        ,"Motor_Temperature_residual_slope": 14.076779102332068
        ,"Vibration_residual_avg": -0.140606111392722
        ,"Vibration_residual_std": 0.7595460467866444
        ,"Vibration_residual_slope": 1.84252120732304
        ,"Discharge_Pressure_trend": "Decrease"
        ,"Frequency_trend": "Increase"
        ,"Intake_Pressure_trend": "Increase"
        ,"Intake_Temperature_trend": "Increase"
        ,"Motor_Temperature_trend": "Increase"
        ,"Vibration_trend": "Increase"
        ,"OIL_RATE_numeric_trend": "Decrease"
        ,"Ampere_trend": "Constant"
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict():\n")
pprint(predict_result)

# In case of classification the following will output a dictionnary of numpy array with
# probabilities for each class
predict_proba_result = model.predict_proba(data_to_score)
print(" \nOutput of model.predict_proba():\n")
pprint(predict_proba_result)
